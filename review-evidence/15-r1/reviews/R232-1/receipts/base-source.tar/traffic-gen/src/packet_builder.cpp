/*
 * SPDX-FileCopyrightText: 2025 Kebag-Logic (https://kebag-logic.com)
 * SPDX-FileCopyrightText: 2025 Alexandre Malki <alexandre.malki@kebag-logic.com>
 * SPDX-License-Identifier: MIT
 */

#include <tsn/packet_builder.h>
#include <tsn/log.h>

#include <cassert>
#include <iostream>
#include <limits>

namespace tsn {

PacketBuilder::PacketBuilder()
    : mRng(std::random_device{}())
{
}

void PacketBuilder::seed(uint64_t s)
{
    mRng.seed(s);
}

void PacketBuilder::appendBits(std::vector<uint8_t>& buf, size_t& bitOffset,
                                uint64_t value, uint32_t numBits)
{
    for (int i = static_cast<int>(numBits) - 1; i >= 0; --i) {
        /* Fields wider than 64 bits carry the picked value in their low
         * 64 bits; higher bits are zero (shifting a uint64 by >= 64 is UB). */
        const int bit = (i < 64) ? static_cast<int>((value >> i) & 1u) : 0;
        const size_t byteIdx = bitOffset / 8;
        const size_t bitInByte = 7 - (bitOffset % 8);  // MSB of byte first

        if (byteIdx >= buf.size()) {
            buf.push_back(0);
        }
        buf[byteIdx] |= static_cast<uint8_t>(bit << bitInByte);
        ++bitOffset;
    }
}

uint64_t PacketBuilder::pickValue(const Var& var)
{
    const auto& expected = var.getExpectedValues();

    /* Exhaustive list takes priority over all other constraints. */
    if (!expected.empty()) {
        std::uniform_int_distribution<size_t> dist(0, expected.size() - 1);
        return expected[dist(mRng)];
    }

    /* Inclusive [min, max] range. */
    if (var.hasRange()) {
        const auto& r = var.getRange();
        const uint64_t lo = (r.min <= r.max) ? r.min : r.max;
        const uint64_t hi = (r.min <= r.max) ? r.max : r.min;
        std::uniform_int_distribution<uint64_t> dist(lo, hi);
        return dist(mRng);
    }

    const uint32_t size = var.getSize();
    if (size == 0) {
        return 0;
    }

    const uint64_t maxVal = (size >= 64)
                            ? std::numeric_limits<uint64_t>::max()
                            : (1ULL << size) - 1ULL;
    std::uniform_int_distribution<uint64_t> dist(0, maxVal);
    uint64_t value = dist(mRng);

    /* Bitmask: only bits within the mask may be set. */
    if (var.hasMask()) {
        value &= var.getMask();
    }

    return value;
}

PacketBuilder::BuiltPacket PacketBuilder::buildWithOverrides(
    const ProtocolInterface& iface,
    const Database<Var>& varDb,
    const std::unordered_map<std::string, uint64_t>& overrides)
{
    BuiltPacket result;
    size_t bitOffset = 0;

    for (const std::string& ref : iface.getVarRefs()) {
        const Var* var = varDb.getElement(ref);
        if (var == nullptr) {
            log(LogLevel::warn) << "PacketBuilder: var_ref '" << ref
                      << "' not found in database, skipping\n";
            continue;
        }

        const uint32_t size = var->getSize();
        if (size == 0) continue;

        const auto pos = ref.rfind("::");
        const std::string shortName =
            (pos != std::string::npos) ? ref.substr(pos + 2) : ref;

        uint64_t value;
        if (!var->getExpectedValues().empty()) {
            /* Hard constraint wins: always pick from the expected set. */
            value = pickValue(*var);
        } else {
            auto it = overrides.find(shortName);
            if (it != overrides.end()) {
                /* Use the propagated value; apply mask if declared. */
                value = it->second;
                if (var->hasMask()) value &= var->getMask();
            } else {
                value = pickValue(*var);
            }
        }

        appendBits(result.bytes, bitOffset, value, size);
        result.fields.emplace_back(shortName, value);
    }

    return result;
}

PacketBuilder::BuiltPacket PacketBuilder::buildWithFields(
    const ProtocolInterface& iface, const Database<Var>& varDb)
{
    BuiltPacket result;
    size_t bitOffset = 0;

    for (const std::string& ref : iface.getVarRefs()) {
        const Var* var = varDb.getElement(ref);
        if (var == nullptr) {
            log(LogLevel::warn) << "PacketBuilder: var_ref '" << ref
                      << "' not found in database, skipping\n";
            continue;
        }

        const uint32_t size = var->getSize();
        if (size == 0) continue;

        const uint64_t value = pickValue(*var);
        appendBits(result.bytes, bitOffset, value, size);

        const auto pos = ref.rfind("::");
        const std::string shortName =
            (pos != std::string::npos) ? ref.substr(pos + 2) : ref;
        result.fields.emplace_back(shortName, value);
    }

    return result;
}

std::vector<uint8_t> PacketBuilder::build(const ProtocolInterface& iface,
                                           const Database<Var>& varDb)
{
    return buildWithFields(iface, varDb).bytes;
}

} /* namespace tsn */
