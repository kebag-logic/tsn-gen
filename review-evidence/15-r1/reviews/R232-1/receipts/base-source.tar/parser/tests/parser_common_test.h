/*
 * SPDX-FileCopyrightText: 2025 Kebag-Logic (https://kebag-logic.com)
 * SPDX-FileCopyrightText: 2025 Alexandre Malki <alexandre.malki@kebag-logic.com>
 * SPDX-License-Identifier: MIT
 */
 

 #pragma once
#include <gtest/gtest.h>

#ifndef PARSER_TESTS_RES_PATH
#error "Undefined PARSER_TESTS_RES_PATH"
#endif
